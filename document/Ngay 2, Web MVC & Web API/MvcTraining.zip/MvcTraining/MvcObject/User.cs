﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MvcObject
{
    public class User
    {
        public string ID { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string DisplayName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public Permission Permission { get; set; }
    }

    public class Permission
    {
        public bool Accounting { get; set; }
        public bool ProductManagement { get; set; }
        public bool SystemAdministration { get; set; }
    }

    public class UserPermission
    {
        User User { get; set; }
        Permission Permission { get; set; }
    }
}
