﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MvcObject
{
    public class Role
    {
        public bool Accounting { get; set; }
        public bool ProductManagement { get; set; }
        public bool Administrators { get; set; }
    }
}
