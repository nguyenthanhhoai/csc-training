﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using MvcObject;

namespace MvcTraining.Models
{
    public class AccountManagement
    {
        readonly string AccountURL = "http://localhost:8081/Account/";

        public User Authenticate(string u, string p)
        {
            using (HttpClient httpClient = new HttpClient())
            {
                string url = string.Format("{0}/{1}?u={2}&p={3}", AccountURL, "Authenticate", u, p);
                var response = httpClient.GetAsync(url).Result;

                User loggedUser = response.Content.ReadAsAsync<User>().Result;

                return loggedUser;
            }
        }

        public User Save(string u, string p, string firstName, string lastName, string displayName, string dob, string permission)
        {
            using (HttpClient httpClient = new HttpClient())
            {
                string url = string.Format("{0}/{1}?u={2}&pw={3}&f={4}&l={5}&d={6}&b={7}&p={8}", AccountURL, "Save", 
                    u, p, firstName, lastName, displayName, dob, permission);
                var response = httpClient.GetAsync(url).Result;

                User loggedUser = response.Content.ReadAsAsync<User>().Result;

                return loggedUser;
            }
        }
    }
}