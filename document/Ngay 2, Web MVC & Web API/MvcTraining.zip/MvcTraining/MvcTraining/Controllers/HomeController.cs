﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcTraining.Models;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using MvcObject;

namespace MvcTraining.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            User loggedUser = null;
            if (Session[ConstantValue.LOGGED_USER] != null)
                loggedUser = Session[ConstantValue.LOGGED_USER] as User;
            else
                return RedirectToAction("Login", "Admin");


            return View(loggedUser);
        }
    }
}
