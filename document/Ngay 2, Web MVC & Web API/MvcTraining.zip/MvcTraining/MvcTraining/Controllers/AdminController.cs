﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcTraining.Models;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using MvcObject;

namespace MvcTraining.Controllers
{
    public class AdminController : Controller
    {   
        //
        // GET: /Admin/
        public ActionResult ManageUser()
        {
            return View();
        }

        public ActionResult Login()
        {
            LoginModel loginModel = new LoginModel();
            loginModel.UserName = "abc";
            return View(loginModel);
        }

        [HttpPost]
        public ActionResult Login(LoginModel model)
        {
            if (ModelState.IsValid)
            {
                model.HasError = false;

                AccountManagement accMgm = new AccountManagement();
                User loggedUser = accMgm.Authenticate(model.UserName, model.Password);

                if (loggedUser != null)
                {
                    Session[ConstantValue.LOGGED_USER] = loggedUser;
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    model.HasError = true;
                    ModelState.AddModelError("Login", "Invalid user. Please try again.");
                }
            }
            else
            {
                model.HasError = true;
            }
            return View(model);
        }

        [HttpPost]
        public ActionResult Save(string username, string password, string firstName, string lastName, string displayName, string dateOfBirth, string permission)
        {
            AccountManagement accMgm = new AccountManagement();
            User u = accMgm.Save(username, password, firstName, lastName, displayName, dateOfBirth, permission);

            if (u != null)
                return Json("success");
            else
                return Json("failed to save");
        }

    }
}
