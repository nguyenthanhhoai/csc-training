﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MvcWebAPI.Models;
//using MvcWebAPI.Models.BusinessObject;
using MvcObject;

namespace MvcWebAPI.Controllers
{
    public class AccountController : ApiController
    {
        [HttpGet]
        public User Authenticate(string u, string p)
        {
            AccountModel accModel = new AccountModel();
            return accModel.Authenticate(u, p);
        }

        [HttpGet]
        public User Save(string u, string pw, string f, string l, string d, string b, string p)
        {
            AccountModel accModel = new AccountModel();

            return accModel.Save(u, pw, f, l, d, b, p);
        }
    }
}
