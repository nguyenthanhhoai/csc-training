﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
//using MvcWebAPI.Models.BusinessObject;
using MvcObject;

namespace MvcWebAPI.Models
{
    public class AccountModel : BaseModel
    {
        public User Save(string u, string p, string firstName, string lastName, string displayName, string dob, string permission)
        {
            User user = null;
            sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
            sqlCommand.CommandText = "User_Save";
            sqlCommand.Parameters.Add(new System.Data.SqlClient.SqlParameter("@username", u));
            sqlCommand.Parameters.Add(new System.Data.SqlClient.SqlParameter("@password", p));
            sqlCommand.Parameters.Add(new System.Data.SqlClient.SqlParameter("@firstName", firstName));
            sqlCommand.Parameters.Add(new System.Data.SqlClient.SqlParameter("@lastName", lastName));
            sqlCommand.Parameters.Add(new System.Data.SqlClient.SqlParameter("@displayName", displayName));
            sqlCommand.Parameters.Add(new System.Data.SqlClient.SqlParameter("@dob", dob));
            sqlCommand.Parameters.Add(new System.Data.SqlClient.SqlParameter("@permission", permission));

            SqlDataReader dr = sqlCommand.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);

                user = MapDataToObject(dt);
            }

            return user;
        }

        public User Authenticate(string username, string password)
        {
            User loginUser = null;

            sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
            sqlCommand.CommandText = "User_Authenticate";
            sqlCommand.Parameters.Add(new System.Data.SqlClient.SqlParameter("@username", username));
            sqlCommand.Parameters.Add(new System.Data.SqlClient.SqlParameter("@password", password));

            SqlDataReader dr = sqlCommand.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);

                loginUser = MapDataToObject(dt);
            }

            return loginUser;
        }

        private User MapDataToObject(DataTable dt)
        {
            User u = new User();
            u.ID = dt.Rows[0]["ID"].ToString();
            u.Username = dt.Rows[0]["Username"].ToString();
            u.LastName = dt.Rows[0]["LastName"].ToString();
            u.FirstName = dt.Rows[0]["FirstName"].ToString();
            u.DisplayName = dt.Rows[0]["DisplayName"].ToString();
            u.CreatedBy = dt.Rows[0]["CreatedBy"].ToString();
            u.ModifiedBy = dt.Rows[0]["ModifiedBy"].ToString();
            u.CreatedDate = DateTime.Parse(dt.Rows[0]["CreatedDate"].ToString());
            u.ModifiedDate = DateTime.Parse(dt.Rows[0]["ModifiedDate"].ToString());
            u.Permission = new Permission();
            u.Permission.Accounting = bool.Parse(dt.Rows[0]["Accounting"].ToString());
            u.Permission.ProductManagement = bool.Parse(dt.Rows[0]["ProductManagement"].ToString());
            u.Permission.SystemAdministration = bool.Parse(dt.Rows[0]["SystemAdministration"].ToString());

            return u;
        }
    }
}