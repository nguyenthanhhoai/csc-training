﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace MvcWebAPI.Models
{
    public class BaseModel
    {
        private string dbConnection;
        private SqlConnection sqlConnection;
        protected SqlCommand sqlCommand;


        protected BaseModel()
        {
            dbConnection = ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString();
            sqlConnection = new SqlConnection(dbConnection);
            sqlConnection.Open();

            sqlCommand = new SqlCommand();
            sqlCommand.Connection = sqlConnection;
        }

        ~BaseModel()
        {
            sqlConnection.Close();
        }
    }
}