$(document).ready(function() {
  $("#menu-btn").click(function() {
    $(".outer").toggleClass('active');
    // $(".nav-wrap").toggleClass('active');
  });
});